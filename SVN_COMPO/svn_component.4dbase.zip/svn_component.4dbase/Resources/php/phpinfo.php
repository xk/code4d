<?php
	print (phpinfo($_SERVER["PHPINFO_WHAT"]));